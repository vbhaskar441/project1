<?php
// Always start this first
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Responsive styles-->
<link rel="stylesheet" href="css/demo-style.css"> 
<!-- Font awosome -->
<link rel="stylesheet" href="css/font-awesome.min.css">  
</head>
<body>

<section class="pading-bottom-30">
	<a style='float:right;margin:1px;' href="index.php" class="btn btn-danger" >Loout</a>
<center><h1>Thank you</h1></center>
</section>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
</html>

