<?php
// Always start this first
session_start();
require_once('config.php');
if (!empty($_POST)){
    if (isset($_POST['email']) && isset($_POST['otp'])) { 
        $qry = "select * from user_tbl where email='".$_POST['email']."' and otp='".$_POST['otp']."'";
        $res = mysqli_query($db,$qry)  or die('select user qry : '.mysqli_error());
        if(mysqli_num_rows($res) > 0){
            while($row= mysqli_fetch_assoc($res)){       
                $_SESSION['user_id'] = $row;    
            }
        }
    }
}
if (isset($_SESSION['user_id']['user_id'])){
    // Grab user data from the database using the user_id
    // Let them access the "logged in only" pages
    header("Location: ".$HOST_URL."dashboard.php");
} else {
    // Redirect them to the login page
    header("Location: ".$HOST_URL."index.php");
}


?>