<?php
error_reporting(0);
session_start();
require_once('config.php');

$flag=0;
if(isset($_REQUEST['email'])){
	$qry = "select otp from user_tbl where email='".$_REQUEST['email']."'";
	$res = mysqli_query($db,$qry)  or die('select opt qry : '.mysqli_error());
	if(mysqli_num_rows($res) > 0){
	   $rand_otp = rand(111111,999999);  
	   $upd_qry = "update user_tbl set otp='".$rand_otp."' where  email='".$_REQUEST['email']."'";  
	   $res = mysqli_query($db,$upd_qry)  or die('upd_qry opt : '.mysqli_error());
	   $flag=1;
	}
}

if($flag=='1'){

	$from = 'Vijay';
	$fromemail='vbhaskar441@gmail.com';
	$to = $_REQUEST['email'];
	$toemail =$_REQUEST['email'];
				
	$subject  = 'OTP Request for Login';
	$message = '<html>
		<head>
		  <title>OTP Request for Login</title>
		</head>
		<body>
			<table border="1" cellpadding="0" cellspacing="0" width="50%" align="center" style="border-collapse:collapse;font-size:15px;"  >
			<tr><td colspan="3" style="font-size:24px;font-weight:bold;text-align:center" align="center"><u>>OTP Request for Login</u></td></tr>					
			<tr>
				<td width="45%" style="padding:5px;border-right:0px;">OTP </td>
				<td align="center" valign="top" style="border-left:0px;border-right:0px;">:</td>
				<td width="55%"  style="padding:5px;border-left:0px;" valign="top"><b>'.$rand_otp.'</b></td>
			</tr>
			</table>
		</body>
		</html>';
	$from = '=?UTF-8?B?'.base64_encode($from).'?=<'.$fromemail.'>';
	$to   = '=?UTF-8?B?'.base64_encode($to).'?=<'.$toemail.'>';
	$result = @mail($toemail, '=?UTF-8?B?'.base64_encode($subject).'?=', 
	$message, 
	"To:".$to."\n" . 
	"From: ".$from."\n" . 
	"MIME-Version: 1.0\n" . 
	"Content-type: text/html; charset=UTF-8");
}
echo $flag;
?>