
<?php
error_reporting(0);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Login</title>
<meta name="title" content="Login"/>
<meta name="description" content=""/>
<meta name="keywords" content=""/>
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet"> 

<!-- Bootstrap -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Responsive styles-->
<link rel="stylesheet" href="css/demo-style.css"> 
<!-- Font awosome -->
<link rel="stylesheet" href="css/font-awesome.min.css">  

</head>
<body>
<section class="pading-bottom-30">
 		<div class="bg_area_1">
 		    <div class="container">  
                <div class="row">

                    <div class="form-box-size login-form-3 box-shadow"> 
                       							
                        <div class="login-form-title-3">
                                   
                            <h3>Login<a style='float:right;margin:1px;' href="register.php" class="btn btn-info" >Register</a></h3> 
                        </div>  
                        <div class="login-form-box-3">
                            <div class="form-wrapper"> 
                              <form name="login" action="login_exe.php" method="post" id="login" >
                                <div class="form-group">                                  
                                  <input maxlength='200' id="email" name="email" class="form-input" placeholder="Email ID" type="text"  required />
                                  <i class="fa fa-user" aria-hidden="true"></i>
                                </div>
                                <div class="form-group" >
                                	<p id="otp_msg"></p>
                                  <input  type='button' class="btn btn-danger" id="genrateotp"  value="Send OTP to Email"  /> 
                                </div>								
                                <div class="form-group">
                                  <label class="form-label" for="OTP">OTP</label>
                                  <input maxlength='6' type="text" name="otp" id="otp" class="form-input"  value="" required />
                                  <i class="fa fa-lock" aria-hidden="true"></i>
                                </div>
								
								
                                
                                <div class="button-style">
                                    <button  class="button login">
                                       Login <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                    </button>
                                </div>
                                
                              </form>
                            </div>
                        </div>  
                        
                    </div>
                </div> 
            </div> 
 		</div> 
 	</section>
	
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="js/main.js"></script>
<script language="javascript">
$(document).ready(function(){

$('#genrateotp').click(function() {
	var email = $('#email').val();
	  var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	  if(!regex.test(email)) {
	    $.post("otp_generate.php", {"email":email }, function(response){
			console.log(response);
	        if(response==1){
	           $('#otp_msg').html("OTP send to Email");

	        }else{
				$("#otp_msg").html('Please Enter Correct Email ID & Try again');
	        }
		});
	  }else{
	    $("#otp_msg").html('Please Enter Correct Email ID & Try again');
	  }

});


$( "#email" ).change(function() {
  $("#otp_msg").val('');
});

});







</script>	




</body>
</html>

