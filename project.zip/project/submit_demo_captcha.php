<?php
error_reporting(0);
session_start();
require_once('config.php');
$flag=0;
if(($_REQUEST['captcha'] == $_SESSION['vercode'])){	
	 $qry = "select * from unique_tbl where unique_code='".$_REQUEST['unique_code']."' ";
        $res = mysqli_query($db,$qry)  or die('select unique code qry : '.mysqli_error());
        $flag='1';
        if(mysqli_num_rows($res) > 0){
        	$flag='2';
        	$usr_qry = "select * from user_tbl where (unique_code ='".$_REQUEST['unique_code']."' or email='".$_REQUEST['email']."')  ";
        	$usr_res = mysqli_query($db,$usr_qry)  or die('select user qry : '.mysqli_error());
        	if(mysqli_num_rows($usr_res) == 0){
	            $ins_sql = "INSERT INTO user_tbl (unique_code, mobile, email)
					VALUES ('".$_REQUEST['unique_code']."', '".$_REQUEST['mobile']."', '".$_REQUEST['email']."')";

				if (mysqli_query($db, $ins_sql)) {
				   $flag='3';
				}
	        }
        }
	
	
}else{
	$flag='0';
}
echo $flag;

?>