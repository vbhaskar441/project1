<?php
	$DB_USER='root';
  	$DB_PASS='';
  	$DB_HOST='localhost';
  	$DB_NAME='project';
  	$HOST_URL = 'http://localhost:8081/project/';
	define('DB_HOST', $DB_HOST);
	define('DB_USER', $DB_USER);
	define('DB_PASSWORD', $DB_PASS);
	define('DB_DATABASE', $DB_NAME);
	$db = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
?>