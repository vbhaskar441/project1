-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2020 at 08:31 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `unique_tbl`
--

CREATE TABLE `unique_tbl` (
  `uid` int(11) NOT NULL,
  `unique_code` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `unique_tbl`
--

INSERT INTO `unique_tbl` (`uid`, `unique_code`, `status`) VALUES
(1, 'Abc01a', 1),
(2, 'Abc02a', 1),
(3, 'Abc01b', 1),
(4, 'Abc02b', 1),
(5, 'Abc01c', 1),
(6, 'Abc02c', 1),
(7, 'Abc01d', 1),
(8, 'Abc02d', 1),
(9, 'Abc01e', 1),
(10, 'Abc02e', 1),
(11, 'Abc01f', 1),
(12, 'Abc02f', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `user_id` int(11) NOT NULL,
  `unique_code` varchar(10) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `otp` varchar(10) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `cdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `mdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`user_id`, `unique_code`, `mobile`, `email`, `otp`, `status`, `cdate`, `mdate`) VALUES
(1, 'Abc01a', '9738256263', 'vbhaskar441@gmail.com', '709086', 1, '2020-08-25 14:00:35', '2020-08-25 14:47:49'),
(2, 'Abc01b', '8660026503', 'vjsj2388@gmail.com', NULL, 1, '2020-08-25 17:35:04', '2020-08-25 17:35:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `unique_tbl`
--
ALTER TABLE `unique_tbl`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `unique_code` (`unique_code`);

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `unique_tbl`
--
ALTER TABLE `unique_tbl`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
